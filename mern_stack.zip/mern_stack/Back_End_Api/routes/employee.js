const router = require('express').Router()
 
const employeeController = require('../controller/employee.controller');
const multer = require('../services/multer.service');

// get all employees
router.get('/list', employeeController.fnGetEmployeeList);
 
// get employee by ID
router.get('/:id',employeeController.fnGetEmployeeByID);
 
// get ID for Update 
router.get('/searchRecord/:fname',employeeController.fnGetEmployeeByName);
 
// create new employee
router.post('/create', multer.upload.single('pic'), employeeController.fnCreateNewEmployee);
 
// update employee
router.put('/:id', multer.upload.single('pic'), employeeController.fnUpdateEmployee);
 
// delete employee
router.delete('/:id',employeeController.fnDeleteEmployee);

// Upload Profile Pic
router.post('/upload/:id', multer.upload.single('pic'), employeeController.fnUploadUserProfilePicture);

 
module.exports = router;