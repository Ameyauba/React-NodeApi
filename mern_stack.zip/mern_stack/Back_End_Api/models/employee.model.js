const mongoose = require('mongoose');
const Schema = mongoose.Schema;
  
const employeeModel = new Schema({

    fname: {
        type: String
    },
    lname: {
        type: String
    },
    email: {
        type: String
    },
    phone: {
        type: Number
    },
    salary: {
        type: Number
    },
    pic: {
        type: String,
        required: true,
        default:
          "https://icon-library.com/images/anonymous-avatar-icon/anonymous-avatar-icon-25.jpg",
      },
}, {
    timestamps: true
});

module.exports = mongoose.model('tbl_employee', employeeModel, 'tbl_employee');