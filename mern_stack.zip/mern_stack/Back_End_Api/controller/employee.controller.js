const _ = require("lodash");
const path = require('path')

const EmployeeModel = require('../models/employee.model');
 
// get all employee list
const fnGetEmployeeList = (req, res)=> {
    //console.log('here all employees list');
    EmployeeModel.find({}, {__v: 0}, (err, employees)=> {
        console.log('We are here');
        if(err)
        res.send(err);
        console.log('Employees', employees);
        res.send(employees)
    });
}
 
// get employee by Name for earch by Name 
const fnGetEmployeeByName = (req, res)=>{
    //console.log('get emp by id');
    EmployeeModel.find({fname: req.params.fname}, (err, employee)=>{
        if(err)
        res.send(err);
        console.log('single employee data',employee);
        res.send(employee);
    })
}

// create new employee
const fnCreateNewEmployee = (req, res) =>{
    //var body = _.pick(req.body, ['fname'], ['lname'], ['email'], ['phone'], ['salary']);
    const employeeReqData = new EmployeeModel({
        fname: req.body.fname, 
        lname: req.body.lname, 
        email: req.body.email,
        phone: req.body.phone, 
        salary: req.body.salary
    });
    console.log('employeeReqData', employeeReqData);
    // check null
    return employeeReqData.save((err, response) => {
        if (err) {
            return res.status(400).json({
                success: false, message: 'Please fill all fields'
            });
        } else {
            return (!response ?
                res.status(404).json({
                    code: 0,
                    message: 'unable to add employee'
                }) :
                res.status(200).json({
                    status: true, message: 'Employee Created Successfully', data: response._id
                })
            );
        }
    });
}

// get employee by ID  for Update 
const fnGetEmployeeByID = (req, res)=>{
    //console.log('get emp by id');
    EmployeeModel.findById({_id: req.params.id}, (err, employee)=>{
        if(err)
        res.send(err);
        console.log('single employee data',employee);
        // res.json({"first_name":"Dheeraj"});
        res.send(JSON.stringify({ status: 200, error: null, response: employee }));
    })
}
 

// update employee
const fnUpdateEmployee = (req, res)=>{
    //var body = _.pick(req.body, ['fname'], ['lname'], ['email'], ['phone'], ['salary']);
    EmployeeModel.findOneAndUpdate({_id: req.params.id}, {
        fname: req.body.fname, 
        lname: req.body.lname, 
        email: req.body.email,
        phone: req.body.phone, 
        salary: req.body.salary
    }, {
        new: true
    }, (err, updated) => {
        console.log('employeeReqData update', updated);
        if (err) {
            return res.status(400).json({
                success: false, message: 'Please fill all fields'
            });
        } else {
            return (!updated ?
                res.status(404).json({
                    code: 0,
                    message: 'unable to add employee'
                }) :
                res.status(200).json({
                    status: true, message: 'Employee updated Successfully'
                })
            );
        }
    });
}
 
// delete employee
const fnDeleteEmployee = async (req, res, next) => {
    try {
        EmployeeModel.findOneAndDelete({_id: req.params.id}, (err, employee)=> {
            if(err)
            res.send(err);
            res.json({success:true, message: 'Employee deleted successully!'});
        })
    } catch (err) {
        logger.log('error', err)
        return next(err);
    }
}

const fnUploadUserProfilePicture = async (req, res, next) => {
        var id = req.params.id;
        
        var exist = await EmployeeModel.findById({_id: id});
        if (exist) {
            var pic = req.file.filename;
            const filePath = path.join( "images", pic )
            console.log('response: ', filePath);
            //console.log('response: ', name);
            EmployeeModel.findOneAndUpdate({ _id: id }, {
                pic: filePath
            }, { new: true, }, (err, data) => {
                if (err) throw err;
                return res.status(200).json({ "code": 1, "message": "profile pic updated successfully", pic: data.pic })
            })
        } else {
            return res.status(400).json({
                code: 0,
                message: 'invalid user_id'
            })
        }
}

module.exports = {
    fnGetEmployeeList,
    fnGetEmployeeByName,
    fnCreateNewEmployee,
    fnGetEmployeeByID,
    fnUpdateEmployee,
    fnDeleteEmployee,
    fnUploadUserProfilePicture
}