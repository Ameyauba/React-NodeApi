
const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const morgan = require('morgan');
const cors = require('cors');
// setup the server port
const port = 5000;

// create express app
const app = express();

app.use(cors())
// import employee routes
const employeeRoutes = require('./routes/employee');

mongoose.Promise = global.Promise;
mongoose.connect('mongodb://localhost:27017/Employee');

app.use(morgan('dev'));

app.use((req, res, next) => {
    res.header('Access-Control-Allow-Origin','*'); 
    res.header('Access-Control-Allow-Headers','*');
    if(req.method === 'OPTIONS'){
        res.header('Access-Control-Allow-Methods','GET,PUT,POST,DELETE,PATCH');
        res.status(200).json({});
    }
    next();
});

// parse request data content type application/x-www-form-rulencoded
app.use(bodyParser.urlencoded({extended: false}));
// parse request data content type application/json
app.use(bodyParser.json());

// create employee routes
app.use('/api/v1/employee', employeeRoutes);

app.use((req,res,next) => {
    const error = new Error('page not found');
    error.status = 404;
    next(error);
});

app.use((error, req, res, next) => {
    res.status(error.status || 500);
    res.json({
        error : {
            message : error.message
        }
    });
});
// listen to the port
app.listen(port, () => console.log(`app listening at http://localhost:${port}`));