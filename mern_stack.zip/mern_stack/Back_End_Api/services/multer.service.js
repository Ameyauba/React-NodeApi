const multer = require('multer')


const multerStorage = multer.diskStorage({
    destination: (req, file, cb) => {
      cb(null, "images/");
    },
    filename: (req, file, cb) => {
        cb(null, file.originalname);
    }
    // filename: (req, file, cb) => {
    //   const ext = file.mimetype.split("/")[1];
    //   const name = file.originalname.split(' ').join('_');
    //   cb(null, `${file.originalname}.${ext}`);
    // },
});

const fileFilter = (req, file, callback) => {
    var ext = file.mimetype
    if (ext !== 'image/png' && ext !== 'image/jpg' && ext !== 'image/jpeg') {
        return callback(new Error('Invalid file type. Only jpg, png and jpeg image files are allowed.'))
    }
    callback(null, true)
}

const upload = multer({
    storage: multerStorage,
    fileFilter: fileFilter,
});  

module.exports = {upload};