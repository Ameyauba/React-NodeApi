import React, { useState, useEffect } from "react";
import axios from "axios";
import { useHistory, useParams } from "react-router-dom";

const UploadPic = () => {

let history = useHistory();
const { id } = useParams();

  const [user, setUser] = useState({ pic: ""});
  const [record,setRecord] = useState([]);
  const { pic } = user;

  const onInputChange = e => {
    setUser({ ...user,[e.target.name]: e.target.file });
  };
  
const postDetails = async e => {  
    e.preventDefault();
    await axios.post(`http://localhost:5000/api/v1/employee/upload/${id}`, user.pic);
    history.push("/");
  };

  useEffect(() => {
    loadUser();
  }, []);

  const loadUser =  () => {
    fetch(`http://localhost:5000/api/v1/employee/${id}`,{
            method: "GET",
          })
            .then((response) => response.json())
            .then((result) => {
                console.log(result);
                setUser({
                    id: id,
                    update: true,
                    pic: result.response[0].pic,
                    fname: result.response[0].fname,
                    lname: result.response[0].lname,
                    email: result.response[0].email,
                    phone: result.response[0].phone,
                    salary: result.response[0].salary,

                });
            })
            .catch((error) => console.log("error", error));
  };

  return (
    <div className="container">
    <div className="row mt-4"> 
     <div className="col-sm-5 col-offset-3 mx-auto shadow p-5">
       <h4 className="text-center mb-4">Upload Profile Pic</h4>
         <h5 className="text-success">Profile Pic : {id.fname} </h5>
         <div className="form-group mb-3">
           <form>
           <input
             id="custom-file"
             type="file"
             className="form-control form-control-lg"
             placeholder="Upload Profile Picture"
             name="pic"
             value={pic}
             onChange={e => onInputChange(e)}
             custom></input>
          </form>
         </div>
         <button onClick={postDetails} className="btn btn-secondary btn-block">Submit Pic</button>
      </div>
     </div> 
   </div>
  );
};

export default UploadPic;
